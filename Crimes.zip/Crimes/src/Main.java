import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.*;

public class Main {
    public static void main(String[] args) throws Exception {

        try {
            FileInputStream stream = new FileInputStream("C:\\Users\\ksush\\Crimes\\src\\Crimes.csv");
            Map<String, Integer> nameColumn = new HashMap<>();
            Scanner scanner = new Scanner(stream);
            String[] nameColumnSplit = scanner.nextLine().split(",");

            for (int i = 0; i < nameColumnSplit.length; i++) {
               nameColumn.put(nameColumnSplit[i], i);
            }

            List<String[]> crimesData = new ArrayList();
            Map<String, Integer> crimes2015 = new HashMap<>();

            for (int i = 0; scanner.hasNext(); i++) {
                String[] ex;
                String[] date;
                String crime;
                if (i==0){
                  scanner.nextLine();
                  ex = scanner.nextLine().split(",");
                  crimesData.add(ex);
                }
                ex = scanner.nextLine().split(",");
                crimesData.add(ex);

                date = ex[nameColumn.get("Date")].split(" ");
                date = date[0].split("/");

                if(Objects.equals(date[2], "2015")){
                    crime = ex[nameColumn.get("Primary Type")];
                    if (!crimes2015.containsKey(crime)){
                        crimes2015.put(crime, 1);
                    }else{
                        crimes2015.replace(crime, (crimes2015.get(crime))+1);
                    }
                }
            }

            for (Map.Entry<String, Integer> entry:
                 crimes2015.entrySet()) {
                System.out.println(entry);
            }


           String mostFreqCrime = "BURGLARY";

            for (String crime:
                 crimes2015.keySet()) {
                if (crimes2015.get(crime)>crimes2015.get(mostFreqCrime)){
                    mostFreqCrime = crime;
                }
            }
            System.out.println("Наиболее частым преступление в 2015 году стало - " + mostFreqCrime);

            } catch (IOException e) {
                    throw new Exception(e);
        }





    }
}